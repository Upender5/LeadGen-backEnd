# LeadGen-backEnd
This assignment involves developing a lead generation application that includes data tracking, scoring, and visualization.
