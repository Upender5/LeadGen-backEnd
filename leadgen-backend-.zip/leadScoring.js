function calculateLeadScore(source) {
    let score = 0;
  
    switch (source) {
      case 'organic':
        score = 10;
        break;
      case 'paid':
        score = 5;
        break;
      case 'referral':
        score = 7;
        break;
      default:
        score = 1;
        break;
    }
  
    return score;
  }
  
  module.exports = { calculateLeadScore };
  