const express = require('express');
const bodyParser = require('body-parser');
const { getAnalyticsData } = require('./analytics');
const { calculateLeadScore } = require('./leadScoring');
const Lead = require('./models/Lead');
const sequelize = require('./sequelize');

const app = express();
const port = 5000;

app.use(bodyParser.json());

// Endpoint to fetch visitor data from Google Analytics
app.get('/api/analytics-data', async (req, res) => {
  try {
    // const authClient = await getAuthenticatedClient();
    const data = await getAnalyticsData();
console.log(data,"data");

    // Extract data and process leads
    const processedData = data.reports[0].data.rows.map(row => {
      const [pagePath, sourceMedium] = row.dimensions;
      const source = sourceMedium.split(' ')[0]; 
      const score = calculateLeadScore(source);

      return { pagePath, source, score };
    });

    res.json(processedData);
  } catch (err) {
    console.error('Error fetching analytics data:', err);
    res.status(500).send('Failed to retrieve analytics data');
  }
});

// Endpoint to create a new lead
app.post('/api/add-lead', async (req, res) => {
  const { name, email, source } = req.body;
  const score = calculateLeadScore(source);

  try {
    const lead = await Lead.create({ name, email, source, score });
    res.json(lead);
  } catch (error) {
    console.error('Error saving lead:', error);
    res.status(500).send('Failed to save lead');
  }
});

sequelize.sync().then(() => {
  app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
  });
});
