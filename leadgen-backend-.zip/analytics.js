// analytics.js
const { BetaAnalyticsDataClient } = require('@google-analytics/data');
const path = require('path');

// Path to your service account key JSON file
const KEY_FILE_PATH = path.join(__dirname, './client_secret_187367697019-50jcrkpp6lic7hkg3ue28o8omn4brb1f.apps.googleusercontent.com.json');

// Replace with your GA4 property ID (numeric ID, not Measurement ID)
const PROPERTY_ID = '470599765';

const analyticsDataClient = new BetaAnalyticsDataClient({
  keyFile: KEY_FILE_PATH,
});

async function getAnalyticsData() {
  const [response] = await analyticsDataClient.runReport({
    property: `properties/${PROPERTY_ID}`,
    dateRanges: [
      {
        startDate: '7daysAgo',
        endDate: 'today',
      },
    ],
    dimensions: [
      { name: 'pagePath' },
      { name: 'sourceMedium' },
    ],
    metrics: [
      { name: 'sessions' },
      { name: 'pageviews' },
    ],
  });

  return response;
}

module.exports = { getAnalyticsData };
