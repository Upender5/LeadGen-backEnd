module.exports = {
    database: 'masterdb',
    username: 'upender',
    password: 'postgres', 
    host: 'localhost',
    dialect: 'postgres',
    port: '5432',
  };